import importlib.util
import unittest
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('aula','src/aula-conecta.py')
a=importlib.util.module_from_spec(spec); spec.loader.exec_module(a)
FIXTURE='''Screen 0: minimum 8 x 8, current 3840 x 1080, maximum 32767 x 32767
eDP-1 connected primary 1920x1080+0+0 (normal left inverted right x axis y axis)
   1920x1080     60.01*+  59.93
   1280x720      60.00
DP-1 connected 1920x1080+1920+0 (normal left inverted right x axis y axis)
   3840x2160     60.00 +
   1920x1080     60.00*
HDMI-1 disconnected (normal left inverted right x axis y axis)
'''
class Core(unittest.TestCase):
 def setUp(self): self.o=a.parse_outputs(FIXTURE)
 def test_parse_and_restore(self):
  self.assertEqual(self.o[1]['pos'],'1920x0')
  args=a.restore_args(self.o)
  self.assertIn('60.01',args)
  self.assertEqual(args[-3:],['--output','HDMI-1','--off'])
 def test_clone_common_only(self):
  cmd=a.display_args(self.o,'DP-1','duplicar')
  self.assertNotIn('3840x2160',cmd)
  self.assertEqual(cmd.count('1920x1080'),2)
 def test_no_common(self):
  self.o[1]['modes']=['800x600']
  with self.assertRaises(RuntimeError): a.display_args(self.o,'DP-1','duplicar')
 def test_disconnect(self):
  with self.assertRaises(RuntimeError): a.display_args(self.o,'HDMI-1','activar')
 def test_extend(self):
  self.assertEqual(a.display_args(self.o,'DP-1','ampliar')[-2:],['--right-of','eDP-1'])
 def test_single_display(self):
  with self.assertRaises(RuntimeError): a.display_args(self.o[:1],'eDP-1','duplicar')
 def test_missing_tool(self):
  self.assertNotEqual(a.run(['/nonexistent/aula'])[0],0)
 def test_watchdog_cancelled(self):
  with patch('time.sleep'),patch.object(a,'run') as run:
   a.watchdog('/nonexistent/cancelled'); run.assert_not_called()
 def test_watchdog_restores(self):
  import tempfile,json
  from pathlib import Path
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'restore.json'; p.write_text(json.dumps(['xrandr','--output','DP-1','--off']))
   with patch('time.sleep'),patch.object(a,'run') as run:
    a.watchdog(str(p)); run.assert_called_once_with(['xrandr','--output','DP-1','--off'])
   self.assertFalse(p.exists())
if __name__=='__main__': unittest.main()
