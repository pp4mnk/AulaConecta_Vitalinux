#!/usr/bin/python3
"""Aula Conecta 0.1.0 — local X11 classroom connection assistant. MIT."""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

VERSION = '0.1.0'

def run(args):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=10,
                           env=dict(os.environ, LC_ALL='C'))
        return p.returncode, p.stdout, p.stderr
    except (OSError, subprocess.TimeoutExpired) as e:
        return 127, '', str(e)

def require(args):
    code, out, err = run(args)
    if code:
        raise RuntimeError(err.strip() or out.strip() or 'La herramienta no respondió.')
    return out

def parse_outputs(text):
    outputs = []
    current = None
    for line in text.splitlines():
        m = re.match(r'^(\S+) (connected|disconnected)\b(.*)', line)
        if m:
            tail = m[3]
            geo = re.search(r'(\d+)x(\d+)\+(-?\d+)\+(-?\d+)', tail)
            rotation = re.search(r'\b(normal|left|right|inverted)\b', tail.split('(')[0])
            current = dict(name=m[1], connected=m[2] == 'connected',
                           primary='primary' in tail, modes=[], mode=None, rate=None,
                           pos=(geo[3]+'x'+geo[4]) if geo else None,
                           rotation=rotation[1] if rotation else 'normal')
            outputs.append(current)
        elif current:
            mode = re.match(r'^\s+(\d+x\d+)\s+(.+)', line)
            if mode:
                current['modes'].append(mode[1])
                for rate in mode[2].split():
                    if '*' in rate:
                        current['mode'] = mode[1]
                        current['rate'] = rate.replace('*','').replace('+','')
    return outputs

def restore_args(outputs):
    args = ['xrandr']
    for o in outputs:
        args += ['--output', o['name']]
        if o['mode']:
            args += ['--mode', o['mode'], '--pos', o['pos'], '--rotate', o['rotation']]
            if o['rate']:
                args += ['--rate', o['rate']]
            if o['primary']:
                args += ['--primary']
        else:
            args += ['--off']
    return args

def display_args(outputs, target, action):
    connected = [o for o in outputs if o['connected']]
    dst = next((o for o in connected if o['name'] == target), None)
    if not dst:
        raise RuntimeError('La pantalla seleccionada ya no está conectada. Pulsa Detectar.')
    if action == 'activar':
        return ['xrandr', '--output', target, '--auto']
    candidates = [o for o in connected if o['name'] != target and o['mode']]
    candidates.sort(key=lambda o: (not o['name'].startswith(('eDP','LVDS')), not o['primary']))
    if not candidates:
        raise RuntimeError('Se necesitan otra pantalla activa y una pantalla de destino.')
    src = candidates[0]
    if action == 'ampliar':
        return ['xrandr', '--output', target, '--auto', '--right-of', src['name']]
    common = set(src['modes']) & set(dst['modes'])
    if not common:
        raise RuntimeError('No hay resolución común. Prueba Ampliar o Configuración de pantalla.')
    mode = max(common, key=lambda x: int(x.split('x')[0])*int(x.split('x')[1]))
    return ['xrandr', '--output', src['name'], '--mode', mode, '--rotate', 'normal',
            '--output', target, '--mode', mode, '--rotate', 'normal', '--same-as', src['name']]

def touch_devices():
    # udev classifies physical touchscreen event devices; avoid treating tablets/mice as touchscreens.
    ids = set()
    for event in Path('/sys/class/input').glob('event*'):
        code, props, _ = run(['udevadm', 'info', '--query=property', '--name=/dev/input/'+event.name])
        if code == 0 and 'ID_INPUT_TOUCHSCREEN=1' in props.splitlines():
            ids.add('/dev/input/'+event.name)
    result = []
    code, listing, _ = run(['xinput','--list','--short'])
    if code == 0:
        for line in listing.splitlines():
            m = re.search(r'id=(\d+)', line)
            if not m:
                continue
            code, props, _ = run(['xinput','--list-props',m[1]])
            node = re.search(r'Device Node.*?:\s*"([^"]+)"', props)
            if node and node[1] in ids:
                name = re.sub(r'^[^\w]+','',line.split('id=')[0]).strip()
                result.append((m[1],name))
    return result

def sinks():
    code, out, _ = run(['pactl','list','short','sinks'])
    if code:
        return []
    return [line.split()[1] for line in out.splitlines() if len(line.split()) > 1]

class App:
    def __init__(self, root):
        self.root = root
        root.title('Aula Conecta · pp4mnk')
        root.geometry('900x700')
        root.minsize(740,580)
        self.pending = None
        self.report = ''
        self.outputs = []
        self.touches = []
        self.audio = []
        frame = ttk.Frame(root, padding=18)
        frame.pack(fill='both',expand=True)
        ttk.Label(frame,text='Aula Conecta',font=('Sans',22,'bold')).pack(anchor='w')
        ttk.Label(frame,text='Pantalla, conexión táctil y sonido · detección local · v'+VERSION).pack(anchor='w',pady=(0,12))
        ttk.Button(frame,text='Detectar de nuevo',command=self.refresh).pack(anchor='w')
        video = ttk.LabelFrame(frame,text='1 · Pantalla de aula',padding=10)
        video.pack(fill='x',pady=8)
        self.screen = ttk.Combobox(video,state='readonly')
        self.screen.pack(fill='x')
        row = ttk.Frame(video); row.pack(fill='x',pady=8)
        self.actions=[]
        for label,act in [('Activar pantalla','activar'),('Duplicar imagen','duplicar'),('Ampliar a la derecha','ampliar')]:
            b=ttk.Button(row,text=label,command=lambda a=act:self.change_display(a)); b.pack(side='left',padx=3); self.actions.append(b)
        ttk.Label(video,text='Los cambios de vídeo se revierten en 20 segundos si no los confirmas.').pack(anchor='w')
        touch = ttk.LabelFrame(frame,text='2 · Táctil USB',padding=10); touch.pack(fill='x',pady=4)
        self.touch=ttk.Combobox(touch,state='readonly'); self.touch.pack(fill='x')
        self.touchbutton=ttk.Button(touch,text='Asociar este táctil a la pantalla elegida',command=self.map_touch)
        self.touchbutton.pack(anchor='w',pady=5)
        sound=ttk.LabelFrame(frame,text='3 · Salida de sonido',padding=10); sound.pack(fill='x',pady=4)
        self.sink=ttk.Combobox(sound,state='readonly'); self.sink.pack(fill='x')
        ttk.Button(sound,text='Usar esta salida para audio nuevo',command=self.set_audio).pack(anchor='w',pady=5)
        self.text=tk.Text(frame,wrap='word',height=8,font=('Sans',10)); self.text.pack(fill='both',expand=True,pady=8)
        row=ttk.Frame(frame); row.pack(fill='x')
        ttk.Button(row,text='Guardar informe',command=self.save).pack(side='left')
        ttk.Button(row,text='Ayuda de conexiones',command=self.help).pack(side='left',padx=8)
        ttk.Label(row,text='Creado por pp4mnk · proyecto independiente').pack(side='right')
        root.protocol('WM_DELETE_WINDOW',self.close)
        root.after(100,self.refresh)

    def refresh(self):
        if self.pending:
            return
        x11 = os.environ.get('XDG_SESSION_TYPE','').lower() != 'wayland' and bool(os.environ.get('DISPLAY'))
        code, raw, err = run(['xrandr','--query']) if x11 else (1,'','Sesión Wayland o sin servidor X11.')
        self.outputs=parse_outputs(raw) if code==0 else []
        connected=[o for o in self.outputs if o['connected']]
        names=[o['name'] for o in connected]
        self.screen['values']=names
        external=[n for n in names if not n.startswith(('eDP','LVDS'))]
        self.screen.set(external[-1] if external else (names[0] if names else ''))
        self.touches=touch_devices() if x11 else []
        self.touch['values']=[i+' · '+n for i,n in self.touches]
        self.touch.set(self.touch['values'][0] if self.touches else '')
        self.audio=sinks(); self.sink['values']=self.audio
        hdmi=[s for s in self.audio if 'hdmi' in s.lower()]
        self.sink.set(hdmi[0] if hdmi else (self.audio[0] if self.audio else ''))
        for b in self.actions:
            b['state']='normal' if connected and x11 else 'disabled'
        self.touchbutton['state']='normal' if self.touches and connected else 'disabled'
        lines=['DIAGNÓSTICO · no se ha modificado la configuración.']
        if code:
            lines.append('Vídeo: no disponible. '+err.strip()+' Usa la configuración de pantalla del escritorio.')
        for o in connected:
            lines.append(o['name']+': '+(o['mode'] or 'conectada, pero desactivada'))
        if len(connected)<2:
            lines.append('No se detecta una segunda pantalla. Comprueba alimentación, entrada HDMI/DP y cable/adaptador.')
        lines.append('Táctiles físicos detectados: '+str(len(self.touches)))
        if not self.touches:
            lines.append('Si la imagen funciona pero no el tacto, conecta también el USB de datos de la pantalla. No se instalan drivers propietarios.')
        lines.append('Salidas de sonido disponibles: '+str(len(self.audio)))
        if not hdmi:
            lines.append('No aparece audio HDMI/DP: revisa el cable y el perfil de sonido en el panel del escritorio.')
        lines.append('La detección no puede identificar con certeza qué monitor corresponde a cada táctil: elige ambos antes de asociarlos.')
        self.report='Aula Conecta '+VERSION+'\n'+'\n'.join(lines)+'\n\nXRANDR\n'+raw+'\nAudio\n'+'\n'.join(self.audio)
        self.text.delete('1.0','end'); self.text.insert('end','\n'.join(lines))

    def change_display(self, action):
        if self.pending:
            return
        try:
            old=parse_outputs(require(['xrandr','--query']))
            # Reject transformed/panned layouts: simple RandR snapshots cannot restore these faithfully.
            verbose=require(['xrandr','--verbose'])
            for m in re.finditer(r'Transform:\s*([\d.\-]+)\s+([\d.\-]+)\s+([\d.\-]+)\s*\n\s*([\d.\-]+)\s+([\d.\-]+)\s+([\d.\-]+)\s*\n\s*([\d.\-]+)\s+([\d.\-]+)\s+([\d.\-]+)',verbose):
                if [float(v) for v in m.groups()] != [1,0,0,0,1,0,0,0,1]:
                    raise RuntimeError('Este escritorio usa escalado avanzado. Utiliza su panel de configuración de pantalla.')
            if re.search(r'panning\s+[1-9]',verbose) or any(re.search(r'\b[xy] axis', line.split('(')[0]) for line in verbose.splitlines() if ' connected ' in line):
                raise RuntimeError('Configuración avanzada de pantalla: utiliza el panel del escritorio.')
            args=display_args(old,self.screen.get(),action)
            rollback=restore_args(old)
            require(['xrandr','--dryrun']+args[1:])
            # Independent watchdog restores even if this application crashes.
            fd,path=tempfile.mkstemp(prefix='aula-conecta-',suffix='.json')
            os.close(fd)
            os.chmod(path,0o600)
            Path(path).write_text(json.dumps(rollback))
            child=subprocess.Popen([sys.executable,os.path.abspath(__file__),'--watchdog',path],start_new_session=True,
                                   stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            self.pending=(path,rollback,child)
            require(args)
            dialog=tk.Toplevel(self.root); dialog.title('¿Se ve bien?'); dialog.transient(self.root)
            ttk.Label(dialog,text='¿Se ve correctamente?\nConfirma en 20 segundos o se restaurará la configuración.',padding=18).pack()
            self.dialog=dialog
            ttk.Button(dialog,text='Sí, conservar',command=lambda:self.finish(True)).pack(pady=5)
            ttk.Button(dialog,text='Restaurar ahora',command=lambda:self.finish(False)).pack(pady=5)
            dialog.protocol('WM_DELETE_WINDOW',lambda:self.finish(False))
            self.timer=self.root.after(20000,lambda:self.finish(False))
        except Exception as e:
            if self.pending:
                self.finish(False)
            messagebox.showerror('No se ha podido aplicar',str(e))

    def finish(self,keep):
        if not self.pending:
            return
        path,args,child=self.pending
        self.pending=None
        if hasattr(self,'timer'):
            self.root.after_cancel(self.timer)
        if hasattr(self,'dialog') and self.dialog.winfo_exists():
            self.dialog.destroy()
        if keep:
            try:
                Path(path).unlink()
            except FileNotFoundError:
                messagebox.showwarning('Plazo terminado','Ya se inició la restauración. Comprueba el resultado y vuelve a intentarlo.')
        else:
            code,out,err=run(args)
            if code:
                messagebox.showerror('Restauración','No se pudo restaurar: '+err+'\nUsa el panel de pantalla del escritorio.')
            Path(path).unlink(missing_ok=True)
        self.refresh()

    def map_touch(self):
        try:
            idx=self.touch.current()
            if idx<0 or self.screen.get() not in [o['name'] for o in self.outputs if o['mode']]:
                raise RuntimeError('Selecciona un táctil y una pantalla activa; pulsa Detectar si acabas de activarla.')
            dev=self.touches[idx][0]
            props=require(['xinput','--list-props',dev])
            m=re.search(r'Coordinate Transformation Matrix.*?:\s*(.*)',props)
            if not m:
                raise RuntimeError('El controlador no ofrece una matriz de asociación compatible.')
            values=[v.strip() for v in m[1].split(',')]
            if len(values)!=9:
                raise RuntimeError('Matriz táctil no reconocida.')
            require(['xinput','--map-to-output',dev,self.screen.get()])
            if not messagebox.askyesno('Prueba el tacto','Toca la pantalla. ¿El puntero aparece en el lugar correcto?\nSi eliges No, se restaura la asociación anterior.'):
                require(['xinput','--set-prop',dev,'Coordinate Transformation Matrix']+values)
        except Exception as e:
            messagebox.showerror('Táctil',str(e))

    def set_audio(self):
        sink=self.sink.get()
        if sink not in sinks():
            messagebox.showerror('Sonido','La salida ya no está disponible. Pulsa Detectar.'); return
        try:
            require(['pactl','set-default-sink',sink])
            messagebox.showinfo('Sonido','Salida predeterminada cambiada. Reinicia la reproducción si una aplicación conserva la salida anterior.\nEl volumen y el silencio no se han modificado.')
        except Exception as e:
            messagebox.showerror('Sonido',str(e))

    def save(self):
        path=filedialog.asksaveasfilename(defaultextension='.txt',initialfile='diagnostico-aula.txt')
        if path:
            try:
                Path(path).write_text(self.report,encoding='utf-8')
            except OSError as e:
                messagebox.showerror('Informe',str(e))

    def help(self):
        messagebox.showinfo('Conexiones de aula','1. Enciende la pantalla y selecciona la entrada HDMI o DisplayPort correcta.\n2. Conecta el cable de vídeo.\n3. Para el tacto, conecta también el USB de datos al ordenador (USB TOUCH).\n4. Pulsa Detectar, elige la pantalla y prueba Duplicar.\n5. Asocia el táctil y selecciona el sonido si hace falta.\n\nUn adaptador debe admitir la dirección de conversión y el audio. El programa no puede sustituir cables ni reparar hardware.\n\nLos cambios de vídeo/táctil se aplican a la sesión; no se crean perfiles de inicio. No hay telemetría ni envío de informes.')

    def close(self):
        if self.pending:
            self.finish(False)
        self.root.destroy()

def watchdog(path):
    import time
    time.sleep(22)
    try:
        args=json.loads(Path(path).read_text())
        # File is created by this process, but restrict commands defensively.
        if isinstance(args,list) and args and args[0]=='xrandr' and all(isinstance(a,str) for a in args):
            run(args)
        Path(path).unlink(missing_ok=True)
    except (OSError,ValueError):
        pass

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--watchdog',help=argparse.SUPPRESS)
    parser.add_argument('--diagnostico',action='store_true',help='Diagnóstico de texto sin interfaz')
    args=parser.parse_args()
    if args.watchdog:
        watchdog(args.watchdog)
    elif args.diagnostico:
        print('Aula Conecta',VERSION)
        for command in [['xrandr','--query'],['pactl','list','short','sinks']]:
            code,out,err=run(command); print('\n'+command[0]+':\n'+out+err)
    else:
        try:
            App(tk.Tk()).root.mainloop()
        except tk.TclError:
            print('No hay escritorio gráfico disponible. Ejecuta aula-conecta desde la sesión del docente.',file=sys.stderr)
            sys.exit(1)
